from db import get_db

def check_multiple_uploads_same_device(device_hash):
    """
    Rule 1: High Risk if the same device hash has uploaded 
    more than 3 documents in the last 10 minutes.
    """
    db = get_db()
    if not db:
        return False
        
    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT COUNT(*) AS cnt FROM device_logs 
            WHERE device_hash = %s AND timestamp >= NOW() - INTERVAL 10 MINUTE
        """, (device_hash,))
        data = cursor.fetchone()

        if data and data["cnt"] >= 3:
            return True  # High risk
        return False
    except Exception as e:
        print(f"[Fraud Check Error] check_multiple_uploads: {e}")
        return False
    finally:
        cursor.close()

def check_multiple_devices_same_user(user_id):
    """
    Rule 2: Suspicious if the same user_id is associated with 
    more than 3 unique device hashes in the last 15 minutes.
    """
    db = get_db()
    if not db:
        return False

    cursor = db.cursor(dictionary=True)
    try:
        cursor.execute("""
            SELECT DISTINCT device_hash 
            FROM device_logs
            WHERE user_id = %s AND timestamp >= NOW() - INTERVAL 15 MINUTE
        """, (user_id,))
        
        devices = cursor.fetchall()
        if len(devices) >= 3:
            return True  # Suspicious
        return False
    except Exception as e:
        print(f"[Fraud Check Error] check_multiple_devices: {e}")
        return False
    finally:
        cursor.close()

def get_user_device_risk_report(user_id):
    """
    Aggregates the specific checks above for the Admin Dashboard.
    Returns a dict with a list of strings in 'risk_flags'.
    """
    db = get_db()
    if not db: return {"risk_flags": []}
    
    risk_flags = []
    cursor = db.cursor(dictionary=True)
    
    try:
        # 1. Check Rule 2 (Multiple devices for this user)
        if check_multiple_devices_same_user(user_id):
            risk_flags.append("SUSPICIOUS: User used multiple devices (>3) within 15 minutes.")

        # 2. Check Rule 1 (High volume from user's devices)
        # We fetch the user's recent devices to check if any are high-volume uploaders
        cursor.execute("SELECT DISTINCT device_hash FROM device_logs WHERE user_id = %s ORDER BY timestamp DESC LIMIT 5", (user_id,))
        user_devices = cursor.fetchall()
        
        for dev in user_devices:
            if check_multiple_uploads_same_device(dev['device_hash']):
                risk_flags.append("HIGH RISK: A device used by this user has excessive upload activity (>3 docs/10min).")
                break # Flag once is enough for the report

        return {"risk_flags": risk_flags}
    except Exception as e:
        return {"risk_flags": [f"Error running fraud checks: {str(e)}"]}
    finally:
        cursor.close()